# -*- coding: utf-8 -*-
# @Author : Zip
# @Moto   : Knowledge comes from decomposition
from __future__ import absolute_import, division, print_function

from quarkml.model.tree_model import *
from quarkml.model.distributed_tree_model import *